number=int(input("enter an integer number"))
remainder=number % 2
if remainder==0:
    print("{} is an even number".format(number))
else:
    print("{} is an odd number".format(number))
    

