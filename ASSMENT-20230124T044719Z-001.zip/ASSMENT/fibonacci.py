n=int(input("enter number")) #10 
x=0
y=1
z=2
while z<=n:
    print(z)
    x=y
    y=z
    z=x+y
