num=int(input("enter value:"))
if num>0:
    print("it is positive")
elif num==0:
    print("it is zero")
else:
    print("it is negetive")
    