a=70
b=98

print("befor swap A=a")
print("befor swap B=b")

tmp=a #65
a=b  #97
tmp=b #65

a,b=b,a
print("after swap A=",a)
print("after swap B=",b)
