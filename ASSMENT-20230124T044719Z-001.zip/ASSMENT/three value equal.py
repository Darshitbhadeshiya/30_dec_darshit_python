a=int(input("enter first value:"))
b=int(input("enter second value:"))
c=int(input("enter third value:"))
if a==b or b==c or c==a:
    print("sum is:",0)
else:
    print("sum is :",a+b+c)
