a=input("enter the aplhabet:")
if a in ('a','e','i','o','u','A','E','I','O',"U"):
    print(a,"is vowel")
else:
    print(a,"is consonat")
    
